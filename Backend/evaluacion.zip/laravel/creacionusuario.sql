USE  sice
CREATE USER 'usuario_app'@'localhost' IDENTIFIED BY '123456';

GRANT USAGE ON sice.* TO 'usuario_app'@'localhost';

REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'usuario_app'@'localhost';
GRANT USAGE ON sice.* TO 'usuario_app'@'localhost';

GRANT EXECUTE ON PROCEDURE sice.sp_insertar_evaluacion TO 'usuario_app'@'localhost';
GRANT EXECUTE ON PROCEDURE sice.sp_mostrar_evaluaciones TO 'usuario_app'@'localhost';
GRANT EXECUTE ON PROCEDURE sice.sp_buscar_evaluacion_por_id_alumno TO 'usuario_app'@'localhost';
GRANT EXECUTE ON PROCEDURE sice.sp_actualizar_evaluacion TO 'usuario_app'@'localhost';
GRANT EXECUTE ON PROCEDURE sice.sp_eliminar_evaluacion TO 'usuario_app'@'localhost';


FLUSH PRIVILEGES;

SHOW GRANTS FOR 'usuario_app'@'localhost';


SHOW CREATE PROCEDURE sice.sp_insertar_evaluacion;