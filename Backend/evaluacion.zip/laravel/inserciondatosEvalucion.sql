USE SICE;

SELECT * FROM grupo;

INSERT INTO genero (nombre_genero)
VALUES ('Masculino'), ('Femenino');

INSERT INTO persona 
(nombre, apellido_paterno, apellido_materno, curp, fecha_nacimiento, id_genero)
VALUES
('Juan','Perez','Lopez','PEPJ900101HSLRRN01','1990-01-01',1);

INSERT INTO persona
(nombre, apellido_paterno, apellido_materno, curp, fecha_nacimiento, id_genero)
VALUES
('Carlos','Ramirez','Lopez','RALC030101HSLPRN01','2003-01-01',1),
('Ana','Martinez','Hernandez','MAHA030202MSLRRN02','2003-02-02',2),
('Luis','Garcia','Torres','GATL030303HSLRRN03','2003-03-03',1),
('Maria','Lopez','Sanchez','LOSM030404MSLRRN04','2003-04-04',2);


SELECT * FROM carrera;

INSERT INTO alumno
(id_persona, numero_control, id_carrera, fecha_ingreso, semestre_actual)
VALUES
(1,'22100001',1,'2022-08-15',5),
(2,'22100002',1,'2022-08-15',5),
(3,'22100003',1,'2022-08-15',5),
(4,'22100004',1,'2022-08-15',5);



INSERT INTO inscripcion
(id_alumno,id_grupo,fecha_inscripcion,estatus)
VALUES
(1,1,'2026-01-10','Activo'),
(2,1,'2026-01-10','Activo'),
(3,1,'2026-01-10','Activo'),
(4,1,'2026-01-10','Activo');

INSERT INTO calificacion (id_inscripcion, id_evaluacion, calificacion)
VALUES
(1, 1, 90.00),
(1, 2, 85.00),
(1, 3, 88.00),
(1, 4, 92.00);


INSERT INTO puesto (nombre_puesto, descripcion)
VALUES ('Docente','Profesor de asignatura');


INSERT INTO empleado
(id_persona, numero_empleado, id_puesto, fecha_contratacion)
VALUES
(1,'EMP001',1,'2020-01-01');


INSERT INTO docente
(id_empleado, grado_academico, especialidad)
VALUES
(1,'Maestria','Sistemas');


INSERT INTO departamento (nombre, descripcion)
VALUES ('Sistemas','Departamento de Sistemas');

INSERT INTO nivel_carrera (nombre_nivel)
VALUES ('Licenciatura');


INSERT INTO carrera
(nombre,id_departamento,id_nivel)
VALUES
('Ingenieria en Sistemas',1,1);



INSERT INTO materia
(clave,nombre,creditos,horas_teoria,horas_practica)
VALUES
('SCD101','Base de Datos',5,3,2);


INSERT INTO periodo
(nombre_periodo,fecha_inicio,fecha_fin)
VALUES
('2026-1','2026-01-01','2026-06-30');


INSERT INTO edificio (nombre_edificio)
VALUES ('Edificio A');

INSERT INTO aula
(id_edificio,nombre,capacidad)
VALUES
(1,'A1',40);


INSERT INTO grupo
(id_materia,id_docente,id_periodo,id_aula,clave_grupo,capacidad)
VALUES
(1,1,1,1,'BD1',40);


INSERT INTO grupo
(id_materia,id_docente,id_periodo,id_aula,clave_grupo,capacidad)
VALUES
(1,1,1,1,'BD2',40);


INSERT INTO evaluacion (id_grupo,nombre,porcentaje)
VALUES
(1,'Tareas',20.00),
(1,'Proyecto',30.00),
(1,'Examen Parcial',20.00),
(1,'Examen Final',30.00);

SELECT * FROM evaluacion;



