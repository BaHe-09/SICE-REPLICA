USE SICE;

/*
Este procedimiento permite registrar una nueva evaluación dentro de un grupo académico.

La evaluación representa un componente de calificación dentro de una materia
*/

DROP PROCEDURE IF EXISTS sp_insertar_evaluacion;

CREATE PROCEDURE sp_insertar_evaluacion(
    IN p_id_grupo INT,
    IN p_nombre VARCHAR(50),
    IN p_porcentaje DECIMAL(5,2)
)
INSERT INTO evaluacion (id_grupo, nombre, porcentaje)
VALUES (p_id_grupo, p_nombre, p_porcentaje);



/*
Este procedimiento tiene como objetivo consultar todos los registros almacenados en la tabla evaluacion.

Su función principal es recuperar la información relacionada con las evaluaciones registradas en el sistema
*/

DROP PROCEDURE IF EXISTS sp_mostrar_evaluaciones;

CREATE PROCEDURE sp_mostrar_evaluaciones()
SELECT
    e.id_evaluacion,
    e.nombre AS evaluacion,
    e.porcentaje,
    g.clave_grupo,
    m.nombre AS materia
FROM evaluacion e
JOIN grupo g ON e.id_grupo = g.id_grupo
JOIN materia m ON g.id_materia = m.id_materia;


/*
Este procedimiento permite consultar una evaluación específica a partir de su identificador.
*/


DROP PROCEDURE IF EXISTS sp_buscar_evaluacion_por_id_alumno;

CREATE PROCEDURE sp_buscar_evaluacion_por_id_alumno(
    IN p_id_alumno INT
)
SELECT 
    a.id_alumno,
    CONCAT(p.nombre,' ',p.apellido_paterno,' ',p.apellido_materno) AS nombre_alumno,
    m.nombre AS materia,
    e.nombre AS evaluacion,
    e.porcentaje,
    c.calificacion
FROM alumno a
JOIN persona p ON a.id_persona = p.id_persona
JOIN inscripcion i ON a.id_alumno = i.id_alumno
JOIN grupo g ON i.id_grupo = g.id_grupo
JOIN materia m ON g.id_materia = m.id_materia
JOIN calificacion c ON i.id_inscripcion = c.id_inscripcion
JOIN evaluacion e ON c.id_evaluacion = e.id_evaluacion
WHERE a.id_alumno = p_id_alumno;


/*
Este procedimiento permite consultar una evaluación específica a partir de su identificador.
*/

DROP PROCEDURE IF EXISTS sp_buscar_evaluacion_por_nombre_alumno;

CREATE PROCEDURE sp_buscar_evaluacion_por_nombre_alumno(
    IN p_nombre VARCHAR(100)
)
SELECT 
    a.id_alumno,
    CONCAT(p.nombre,' ',p.apellido_paterno,' ',p.apellido_materno) AS nombre_alumno,
    m.nombre AS materia,
    e.nombre AS evaluacion,
    e.porcentaje,
    c.calificacion
FROM alumno a
JOIN persona p ON a.id_persona = p.id_persona
JOIN inscripcion i ON a.id_alumno = i.id_alumno
JOIN grupo g ON i.id_grupo = g.id_grupo
JOIN materia m ON g.id_materia = m.id_materia
JOIN calificacion c ON i.id_inscripcion = c.id_inscripcion
JOIN evaluacion e ON c.id_evaluacion = e.id_evaluacion
WHERE p.nombre LIKE CONCAT('%',p_nombre,'%');



/*
Este procedimiento permite consultar una evaluación específica a partir de su identificador.
*/
DROP PROCEDURE IF EXISTS sp_buscar_evaluacion_por_curp;

CREATE PROCEDURE sp_buscar_evaluacion_por_curp(
    IN p_curp VARCHAR(18)
)
SELECT 
    a.id_alumno,
    CONCAT(p.nombre,' ',p.apellido_paterno,' ',p.apellido_materno) AS nombre_alumno,
    m.nombre AS materia,
    e.nombre AS evaluacion,
    e.porcentaje,
    c.calificacion
FROM alumno a
JOIN persona p ON a.id_persona = p.id_persona
JOIN inscripcion i ON a.id_alumno = i.id_alumno
JOIN grupo g ON i.id_grupo = g.id_grupo
JOIN materia m ON g.id_materia = m.id_materia
JOIN calificacion c ON i.id_inscripcion = c.id_inscripcion
JOIN evaluacion e ON c.id_evaluacion = e.id_evaluacion
WHERE p.curp = p_curp;


/*
El procedimiento sp_actualizar_evaluacion permite modificar la información de una evaluación existente.
*/

DROP PROCEDURE IF EXISTS sp_actualizar_evaluacion;

CREATE PROCEDURE sp_actualizar_evaluacion(
    IN p_id_evaluacion INT,
    IN p_id_grupo INT,
    IN p_nombre VARCHAR(50),
    IN p_porcentaje DECIMAL(5,2)
)
UPDATE evaluacion
SET
    id_grupo = p_id_grupo,
    nombre = p_nombre,
    porcentaje = p_porcentaje
WHERE id_evaluacion = p_id_evaluacion;


/*
Este procedimiento permite eliminar una evaluación existente del sistema.
*/

DROP PROCEDURE IF EXISTS sp_eliminar_evaluacion;

CREATE PROCEDURE sp_eliminar_evaluacion(
    IN p_id_evaluacion INT
)
DELETE FROM evaluacion
WHERE id_evaluacion = p_id_evaluacion
AND id_evaluacion NOT IN (
    SELECT id_evaluacion FROM calificacion
);

CALL sp_insertar_evaluacion(1, 'Tareas', 20.00);
CALL sp_insertar_evaluacion(1, 'Proyecto', 30.00);
CALL sp_insertar_evaluacion(1, 'Examen Parcial', 20.00);
CALL sp_insertar_evaluacion(1, 'Examen Final', 30.00);

SELECT * FROM evaluacion;


CALL sp_mostrar_evaluaciones();


CALL sp_buscar_evaluacion_por_nombre_alumno('Carlos');

SELECT * FROM evaluacion;

CALL sp_actualizar_evaluacion(1,1,'Tareas Modificadas',25.00);

SELECT * FROM evaluacion;

CALL sp_eliminar_evaluacion(7);

SELECT * FROM evaluacion;