USE SICE;
SELECT * FROM alumno;


UPDATE evaluacion
SET nombre = 'Tareas Modificadas'
WHERE id_evaluacion = 2;


SELECT * FROM evaluacion;

DELETE FROM evaluacion
WHERE id_evaluacion = 6;

SELECT * FROM evaluacion;